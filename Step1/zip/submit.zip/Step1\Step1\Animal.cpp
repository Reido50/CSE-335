/**
 * \file Animal.cpp
 *
 * \author Reid Harry
 */

#include "Animal.h"

/**
* CAnimal destructor
*/
CAnimal::~CAnimal()
{
}